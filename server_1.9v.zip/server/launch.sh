if [ "$(id -u)" -ne 0 ]; then
  echo "Please run the server by \"sudo bash launch.sh\""
  exit 1
fi

while true; do
  sudo ./gtps
  exit_code=$?
  if [ $exit_code -ne 42 ]; then
    break
  fi
done
